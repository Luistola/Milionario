import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConcursosRoutingModule } from './concursos-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { ConcursosComponent } from './concursos.component';
import { ParticipantesComponent } from '../participantes/participantes/participantes.component';
import { AddEntiresModalComponent } from '../add-entires-modal/add-entires-modal.component';
import { NO_ERRORS_SCHEMA } from '@angular/compiler/src/core';
import { VotoModalComponent } from '../voto-modal/voto-modal.component';



@NgModule({
  declarations: [ConcursosComponent, ParticipantesComponent, AddEntiresModalComponent,VotoModalComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ConcursosRoutingModule,
    FormsModule
    
  ],
  exports:[AddEntiresModalComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class ConcursosModule { 
  
}
